from zhipuai_embedding import ZhipuAIEmbeddings
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
import streamlit as st

def get_vectordb():
    # 定义 Embeddings
    embedding = ZhipuAIEmbeddings()
    # 向量数据库持久化路径
    persist_directory="/Users/xiukai.yu/work/py_workspace/langchain/chroma_db"
    # 加载数据库
    vectordb = Chroma(
        persist_directory=persist_directory,  # 允许我们将persist_directory目录保存到磁盘上
        embedding_function=embedding
    )
    print(f"向量库中存储的数量：{vectordb._collection.count()}")
    return vectordb

def get_chat_qa_chain(input_text):
    vectordb = get_vectordb()
    model = ChatOpenAI(
        model='deepseek-chat',
        openai_api_key='sk-f39fe1d883d444dea19711206412e023',
        base_url='https://api.deepseek.com'
    )
    memory = ConversationBufferMemory(
        memory_key="chat_history",  # 与 prompt 的输入变量保持一致。
        return_messages=True  # 将以消息列表的形式返回聊天记录，而不是单个字符串
    )
    retriever=vectordb.as_retriever()
    qa = ConversationalRetrievalChain.from_llm(
        model,
        retriever=retriever,
        memory=memory
    )
    result = qa({"question": input_text})
    return result['answer']


def main():
    st.set_page_config(page_title="文档回答", layout="wide")
    st.title("文档回答")
    if 'messages' not in st.session_state:
        st.session_state.messages = []

    messages = st.container(height=1000)
    if prompt := st.chat_input("Say something"):
        # 将用户输入添加到对话历史中
        st.session_state.messages.append({"role": "user", "text": prompt})

        # 调用 respond 函数获取回答
        answer = get_chat_qa_chain(prompt)
        # 检查回答是否为 None
        if answer is not None:
            # 将LLM的回答添加到对话历史中
            st.session_state.messages.append({"role": "assistant", "text": answer})

        # 显示整个对话历史
        for message in st.session_state.messages:
            if message["role"] == "user":
                messages.chat_message("user").write(message["text"])
            elif message["role"] == "assistant":
                messages.chat_message("assistant").write(message["text"])


if __name__ == "__main__":
    main()
